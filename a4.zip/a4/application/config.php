<?php
define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:21941/a4/');

//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'pjrivera');
define('DB_PASS', 'pjrivera');
define('DB_NAME', 'pjrivera_db');
?>
