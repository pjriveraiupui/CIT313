<div id="footer">
  <div>
    <ul class="navigation">
      <li class="active">
        <a href="index.php">Home</a>
      </li>
      <li>
        <a href="about.php">About</a>
      </li>
      <li>
        <a href="rooms.php">Rooms</a>
      </li>
      <li>
        <a href="dives.php">Dive Site</a>
      </li>
      <li>
        <a href="foods.php">Food</a>
      </li>
      <li>
        <a href="news.php">News</a>
      </li>
      <li>
        <a href="contact.php">Contact</a>
      </li>
    </ul>
    <div id="connect">
      <a href="http://pinterest.com/fwtemplates/" target="_blank" class="pinterest"></a> <a href="http://freewebsitetemplates.com/go/facebook/" target="_blank" class="facebook"></a> <a href="http://freewebsitetemplates.com/go/twitter/" target="_blank" class="twitter"></a> <a href="http://freewebsitetemplates.com/go/googleplus/" target="_blank" class="googleplus"></a>
    </div>
  </div>
  <p>
    © 2023 by BHACCASYONIZTAS BEACH RESORT. All Rights Reserved
  </p>
</div>
</div>
