<?php

define("URL_ROOT", "http://corsair.cs.iupui.edu:21941/ex1/");
?>
