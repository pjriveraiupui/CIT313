<?php

define("ABSOLUTE_PATH", "/home/pjrivera/htdocs/ex1/");

define("URL_ROOT", "http://corsair.cs.iupui.edu:20271/ex1/");
?>
