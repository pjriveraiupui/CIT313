<?php

class NotFoundController extends Controller{



	public function index(){

	}

}
?>
