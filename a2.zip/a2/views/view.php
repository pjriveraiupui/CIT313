<!DOCTYPE html>
<html>
<head>
  <title>MVC</title>
</head>
<body>
  <h1>Hello From My View!</h1>
  <?php

  echo "<ul>". "<li>" . "User ID: ".$userID. "</li>" .
  "<li>" . "First Name: " .$firstname. "</li>" .
  "<li>" . "Last Name: " .$lastname. "</li>" .
  "<li>" . "Email: " .$email. "</li>" .
  "<li>" . "Role: " . $role . "</li>"  .
   "</ui>";
  ?>
</body>
</html>
