<?php

class LoginController extends Controller{



   public function do_login(){

	 }
	   


}
