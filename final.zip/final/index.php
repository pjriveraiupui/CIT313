<?php

// Display errors in production mode


// let's get started
require 'application/router.php';
