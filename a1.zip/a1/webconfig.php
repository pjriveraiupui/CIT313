<?php

define('ABSOLUTE_PATH', '/home/pjrivera/htdocs/a1');
define('URL_ROOT', 'http://corsair.cs.iupui.edu:21941/a1');
